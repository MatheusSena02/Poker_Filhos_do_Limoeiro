#ifndef CARTASEJOGADOR_H
#define CARTASEJOGADOR_H

#include "cartas.h"
#include "jogador.h"

#endif